


#Checking all required packages
req.pck<-c('raster','terra','dplyr','gdalUtilities','ggrepel','ggforce','XML')
pck<-data.frame(installed.packages())$Package

install.packages(setdiff(req.pck,pck))

##########################################################
######## Grid para obter as medias por quadrante #########
##########################################################

gridPoint<-function(raster,point){
  #point<-inv; raster<- raster; point_id<-"id"
  
  values(raster)<-1:length(values(raster))
  
  #Barra de progresso
  total <- nrow(point@data)
  print("Obtaining the points of each grid")
  pb <- txtProgressBar(min = 0, max = total, style = 3)
  
  for (i in 1:nrow(point@data)){
    
    if(i==1) vars<- vector()
    
    indv<- point[i,]
    pp<- raster::extract(raster,indv)
    vars<- c(vars, pp)
    
    #Atualizando Barra de Progresso
    setTxtProgressBar(pb, i)
    
  }
  
  
  mt<-matrix(vars, nrow=nrow(point), ncol=1)
  df.pixel<- data.frame(mt); names(df.pixel)<-"ID_Pixel"
  df.pixel$id<- point$id
  
  return(df.pixel)
  
}
##########################################################
##################  Download WorldClim  ##################
##########################################################

getWC<-function(var=NULL,res=NULL){
  #var='elev';res="r5min"
  load('./Functions_GISPLS/WC_links.rda')
  
  if("./Covariates" %in% list.dirs() == F) dir.create("Covariates")
  if(paste0("./Covariates/",res) %in% list.dirs() == F) dir.create(paste0("./Covariates/",res))
  
  file<-links[(links$variable%in%var) &(links$res == res),]$link

  options(timeout=6000)
  
  for(i in 1:length(file)){
  download.file(destfile = "./Covariates/getWC.zip",url = file[i])
  unzip("./Covariates/getWC.zip",exdir = paste0("./Covariates/",res,"/"))
  }
  options(timeout=60)
  file.remove("./Covariates/getWC.zip")
  
}
##########################################################
##################  Download SoilGrids  ##################
##########################################################

require('XML')
require(gdalUtilities)
require(raster)

#Profundidades
#0-5cm_mean
#5-15cm_mean
#15-30cm_mean
#30-60cm_mean
#60-100cm_mean
#100-200cm_mean


#Propriedades
#bdod
#cec
#cfvo
#clay
#nitrogen
#ocd
#ocs
#phh2o
#sand
#silt
#soc - soil organic carbon 
#wrb


#vetores com os atributos e profundidades

getSG<-function(attributes = NULL, layers ="30-60cm_mean", resample = F, raster=NULL,tr=c(4500,4500)){
  
  #attributes = "bdod";layers ="30-60cm_mean";tr=c(4500,4500);resample = T;raster=raster("./Covariates/r2.5min/wc2.1_2.5m_elev.tif")
    
    if("./Covariates" %in% list.dirs() == F) dir.create("Covariates")
    if("./Covariates/getSG" %in% list.dirs() == F) dir.create("./Covariates/getSG")
  
  sg_url="/vsicurl/https://files.isric.org/soilgrids/latest/data/"
  
  if(resample ==F){
    for (i in 1:length(attributes)) {
      for (j in 1:length(layers)) {
        cat("\nDOWNLOADING",paste0(attributes[i],layers[j],'\n'))
        
        datos = paste0(attributes[i], "/", attributes[i], "_", layers[j], ".vrt") #attr + layer
        lfile = paste0("./Covariates/getSG/sg.", attributes[i], layers[j],".tiff") #output path
        
        gdal_translate(paste0(sg_url, datos), lfile,tr =tr)
        
        
      }
    }
  }else{
    for (i in 1:length(attributes)) {
      for (j in 1:length(layers)) {
        cat("\n\nDOWNLOADING:",paste0(attributes[i],layers[j],'\n'))
        
        datos = paste0(attributes[i], "/", attributes[i], "_", layers[j], ".vrt") #attr + layer
        lfile = paste0("./Covariates/getSG/sg.", attributes[i], layers[j],".tiff") #output path
        
        gdal_translate(paste0(sg_url, datos), lfile,tr = tr)
        
        #Changing the projection and ressampling
        cat("\nRessampling...\n")
        gs<-rast(lfile)
        gs<-project(gs,projection(raster))
  
        gs.res<-resample(gs,terra::rast(raster))
        res<- paste0("r",res(gs.res)[1]*60,"min")
        
        if(paste0("./Covariates/",res) %in% list.dirs() == F) dir.create(paste0("./Covariates/",res))
        writeRaster(gs.res,paste0("./Covariates/",res,"/sg.", attributes[i], layers[j],".tiff"), overwrite=TRUE)
        ?writeRaster
        cat("DONE!")
 

      }
    }
  }
}


#########################################################
############# Construindo rasters Lon e Lat #############
#########################################################

getLonLat<-function(raster){
  
  #importando raster molde

  #Criando rasters auxiliares para lat e long
  lat<-lon<-raster
  
  #Atribuindo os valores para cada um dos rasters
  values(lat)<- yFromCell(raster,cell = 1:ncell(raster))
  values(lon)<- xFromCell(raster,cell = 1:ncell(raster))

  #Cortando para o raster molde
  lat<-mask(lat,raster)
  lon<-mask(lon,raster)
  
  if("./Covariates" %in% list.dirs() == F) dir.create("Covariates")
  res<- paste0("r",res(raster)[1]*60,"min")
  
  if(paste0("./Covariates/",res) %in% list.dirs() == F) dir.create(paste0("./Covariates/",res))
  
  writeRaster(lat,paste0("./Covariates/",res,"/latitude.tiff"), overwrite=TRUE)
  writeRaster(lon,paste0("./Covariates/",res,"/longitude.tiff"), overwrite=TRUE)
  
  return(stack(lon,lat))
  
}

##########################################################
######### Stack de rasters em uma mesma pasta ############
##########################################################

stackRasters<-function(path,pattern){
  #path = "./Rasters_2.5m/";pattern = ".tif"
  
  (rasters<- c(list.files(path = path,pattern = pattern)))
  
  for (i in 1:length(rasters)){
    a.sub <- raster(paste0(path, rasters[i]))
    if(i == 1) { e <- a.sub } else { e <- stack(e,a.sub)}}
  
  return(e)
  
}

##########################################################
####### Extra��o de dados em rasters por ponto ###########
##########################################################

rastertype<- function(stack,points,point_id=NULL){
  #stack = e[[1:24]]; points = data_coord
  
  vars<-vector()
  cat("EXTRACAO DE DADOS AMBIENTAIS A PARTIR DE RASTERS\n")
  
  for (j in 1:length(names(stack))){   
    
    a<- stack[[j]]
    
    #Barra de progresso
    total <- nrow(points@data)
    cat("\nRASTER:",names(a),"\t",j,"/",length(names(stack)),"\n")
    
    pb <- txtProgressBar(min = 0, max = total, style = 3)
    
    for ( i in 1:nrow(points@data)){
      
      indv<- points[i,]
      pp<- raster::extract(a,indv) 
      vars<- c(vars, pp)
      
      #Atualizando Barra de Progresso
      setTxtProgressBar(pb, i)
    }       
    cat("\n")
  }
  
  mt<-matrix(vars, nrow=nrow(points), ncol=length(names(stack)))
  edacli<- data.frame(mt); names(edacli)<- names(stack)
  
  if(is.null(point_id) ==T) point_id<-1:nrow(points@data)
  edacli$id<- point_id
  
  edacli<-cbind(data.frame(points),edacli)
  
  
  return(edacli)
}

##########################################################
############### Ajuste do modelo PLS  ####################
##########################################################

fitGISPLS<-function(data,config=NULL,genotype=NULL,
                     env=NULL,resp=NULL, pred=NULL,c=2,
                     selected_cov= NULL){
  
  #config=config; data = ;selected_cov= gcov
  
  if(is.null(config)== FALSE){
    genotype<- config$genotype
    env<- config$env
    resp<-config$resp
    pred<- config$pred
  }
  
  na<-nrow(data)- nrow(na.exclude(data))
  if(na!=0){
    warning(paste0("\nDroping ",na," rows with NA") )
    data<-na.exclude(data)
  }
  
  names(data)[match(genotype,names(data))]<-"genotype"
  names(data)[match(env,names(data))]<-"env"
  gen<-as.character(unique(data$genotype))
  data$id<-1:nrow(data)
  
  for (j in 1:length(gen)){
    
    if(j==1){
      r2.leave<-vector()
      ima.pred<-vector()
      predict<-vector()
      observ<-vector()
      geno<-vector()
      env<-vector()
      gg.ima<-list()
      lat<-vector()
      point<-vector()
      
    }
    
    cat("\n\nGISPLS: FITTING ENVIRONMENTAL COEFFICIENTS :",gen[j],'\n')
    
    df.gen<-data[data$gen == gen[j],] 
    predictors<-df.gen[pred]
    response <- df.gen[resp]
    
    if(is.null(selected_cov)==T){
      
      total <- nrow(df.gen)
      # Barra de progresso
      pb <- txtProgressBar(min = 0, max = total, style = 3)
      
      #PLS
      pls <-plsreg1(predictors = predictors,response = response,comps = c,crosval = T)
      
      #Latent variables
      coo<-as.data.frame(pls$cor.xyt[,c('t1','t2')])
      coo$var<-rownames(coo)
      coo$gen <-gen[j]
      circle <- coo
      
    }else{
      
      gr<-selected_cov$selected[selected_cov$selected$gen == gen[j],]$groups
      sel.covs<-selected_cov$groups[selected_cov$groups$groups %in% strsplit(gr,split=';')[[1]],]$covs
      
      total <- nrow(df.gen)
      # Barra de progresso
      pb <- txtProgressBar(min = 0, max = total, style = 3)
      
      #PLS
      pls <-plsreg1(predictors = predictors[sel.covs],response = response,comps = c,crosval = T)
      
      pls$std.coefs
      #Latent variables
      coo<-as.data.frame(pls$cor.xyt[,c('t1','t2')])
      coo$var<-rownames(coo)
      coo$gen <-gen[j]
      circle <- coo
      
    }
    
    geno<-c(geno, as.character(df.gen$genotype))
    env<-c(env,df.gen$env)
    point<-c(point,df.gen$id)
    
    #Atualizando Barra de Progresso
    setTxtProgressBar(pb, total)
    
    pls.coefs<-rep(0,length(pred)+1)
    names(pls.coefs)<-c("Intercept",names(data[pred]))
    pls.coefs_std<-pls.coefs[-1]
    
    pls.coefs[names(pls$reg.coefs)]<-pls$reg.coefs
    pls.coefs_std[names(pls$std.coefs)]<-pls$std.coefs
    
    value<-as.numeric(data.matrix(cbind(1,predictors))%*%(pls.coefs))
    predict<- c(predict,value)
    observ<- c(observ,response[,1])
    
    if(j==1) {
      beta<-pls.coefs
      beta_std<-pls.coefs_std
      CIRCLE<-circle
    }else
    {
      beta<-cbind(beta,pls.coefs)
      beta_std<- cbind(beta_std,pls.coefs_std)
      CIRCLE<- rbind(CIRCLE,circle)
      row.names(CIRCLE)<-1:nrow(CIRCLE)
    }
    
    
    if(j == length(gen)) df.loo<- data.frame(Genotype= geno, Env = env, Predicted = predict, Observed = observ)
  }
  
  require(dplyr)
  beta<- as.data.frame(beta)
  beta_std<- as.data.frame(beta_std)
  names(beta)<-names(beta_std)<-gen
  df.metrics<-df.loo %>% group_by(Genotype) %>% summarise(R2 = round(cor(Predicted, Observed) ^ 2,4),
                                                          RMSE = sqrt(mean((Predicted - Observed)^2)))
  
  
  return(list(values = df.loo,metrics = df.metrics,
              coef= beta, std_coef = beta_std,
              circle_coord= CIRCLE, is.gispls =TRUE,
              response= names(response), predictors = names(predictors), genotypes =gen))
}


#############################################################
############### Validacao do modelo PLS  ####################
#############################################################


validateGISPLS<-function(data,config=NULL,genotype=NULL,env=NULL,resp=NULL, pred=NULL,c=2,tendency= T){
  
  if(is.null(config)== FALSE){
    genotype<- config$genotype
    env<- config$env
    resp<-config$resp
    pred<- config$pred
  }
 #data<-df_cov
  na<-nrow(data)- nrow(na.exclude(data))
  if(na!=0){
    warning(paste0("\nDroping ",na," rows with NA") )
    data<-na.exclude(data)
  }
  names(data)[match(genotype,names(data))]<-"genotype"
  names(data)[match(env,names(data))]<-"env"
  gen<-as.character(unique(data$genotype))
  data$id<-1:nrow(data)
  
  for (j in 1:length(gen)){
    
    if( j==1){
      r2.leave<-vector()
      ima.pred<-vector()
      predict<-vector()
      observ<-vector()
      geno<-vector()
      env<-vector()

    }
    
    cat("\n\nLEAVE ONE OUT:",gen[j],'\n')
    
    
    df.gen<-data[data$gen == gen[j],] #ACHAR UM JEITO DE AUTOMATIZAR
    predictors<-df.gen[pred]
    response <- df.gen[resp]
    
    total <- nrow(df.gen)
    # Barra de progresso
    pb <- txtProgressBar(min = 0, max = total, style = 3)
    
    
    for( i in 1:total){
      
      pls <-plsreg1(predictors = predictors[-i,],response = response[-i,],comps = c,crosval = T)
      
      
      geno<-c(geno, gen[j])
      env<-c(env,df.gen[i,]$env)

      
      #Atualizando Barra de Progresso
      setTxtProgressBar(pb, i)
      
      pls.coefs<-pls$reg.coefs
      value<-t(c(1,as.numeric(predictors[i,])))%*%(pls$reg.coefs)
      predict<- c(predict,value)
      observ<- c(observ,response[i,])
      
    }
    
    if(j == length(gen)) df.loo<- data.frame(Genotype= geno, Env = env, Predicted = predict, Observed = observ, Residual = observ-predict)
  }
  
  require(dplyr)
  
  df.metrics<-df.loo %>% group_by(Genotype) %>% summarise(R2 = round(cor(Predicted, Observed) ^ 2,4),
                                                          RMSE = sqrt(mean((Predicted - Observed)^2)))
  
  
  if(tendency== T){
  (rmse.mean<-mean(df.metrics$RMSE))
  
  df.loo<-df.loo %>% mutate(Predictive_Tendency = case_when(Residual < -rmse.mean ~ "Overestimated",
                                                 Residual > rmse.mean ~ "Underestimated",
                                                 (Residual < rmse.mean) & ( Residual > - rmse.mean) ~ "Expected"))
  
  
  
  
  
  return(list(values = df.loo,metrics = df.metrics,rmse.mean= rmse.mean))
  
  }else{
    
    return(list(values = df.loo,metrics = df.metrics))
  }
}

#############################################################
############### An�lise de covari�veis   ####################
#############################################################

covariatesAnalysis<-function(gispls,rank,pred_names=NULL,resp_name=NULL){
  #rank=5;gispls<-fit;resp_name = "MAI";pred_names=c("LATI","LONG","BDOD","CEC","CLAY","SAND",paste0("BIO",1:19),"ELEV")
  #rank=5;gispls<-fit_sel;resp_name ="OI";pred_names= NULL
  
  if(gispls$is.gispls == T){
    
    gen<-names(gispls$std_coef)
    
    #resp_name
    if(is.null(resp_name) ==T) resp_name <- gispls$response
    
    #pred_names
    if(is.null(pred_names)== T) pred_names<- gispls$predictors
    
    rownames(gispls$std_coef)<-rownames(gispls$coef)[-1]<-pred_names
    
    df.pred<-data.frame(var= c(gispls$predictors,gispls$response),
                        choosen_names = c(pred_names,resp_name))
    
    
    for(i in 1:length(gen)){
      
      if(i==1)g<-list()
      
      #Rankeando
      df.gen<-gispls$std_coef[order(abs(gispls$std_coef[,i]),decreasing = T),][gen[i]]
      best_cov<-rownames(df.gen)[1:rank]
      circle.gen<-gispls$circle_coord[gispls$circle_coord$gen == gen[i],]
      circle.gen<-merge(circle.gen,df.pred)
      
      #Tabela com as vari�veis mais imoportantes
      df.rank<-data.frame(genotype = gen[i],rank=1:rank,covariates = best_cov,effects =gispls$coef[best_cov,gen[i]], stdeffects = df.gen[best_cov,1])
      
      #cores
      circle.gen$highlight<-ifelse(circle.gen$choosen_names %in% c(best_cov,resp_name),circle.gen$choosen_names,"")
      circle.gen$covs<-ifelse(circle.gen$choosen_names %in% c(best_cov,resp_name),"",circle.gen$choosen_names)
      
      col.cov<-match(best_cov,circle.gen$highlight)
      col.resp<-match(resp_name,circle.gen$highlight)
      
      circle.gen$col<-"#0077b6";  circle.gen$col[col.cov]<-"black";circle.gen$col[col.resp]<-"orange"
      
      #Circulo de correla��es
      g[[i]]<-ggplot(circle.gen,aes(x=t1,y=t2))+
        ggforce::geom_circle(aes(x0 = 0, y0 = 0, r = 1),inherit.aes = FALSE,color="white")+
        geom_point(size=0.1)+
        geom_segment(aes(x = 0, y = 0, xend = t1, yend = t2), col = circle.gen$col)+
        labs(title = gen[i])+
        xlim(c(-1.2,1.2))+
        ylim(c(-1.2,1.2))+
        
        geom_text(aes(label=covs),size=6,col =circle.gen$col)+
        ggrepel::geom_label_repel(aes(label=highlight),size=6,col= circle.gen$col)+
        theme(plot.title = element_text(size = 26, face = "bold"),
              plot.subtitle =  element_text(size = 22),
              axis.title =element_text(size = 18),
              axis.text =element_text(size = 16),
              axis.text.x = element_blank(),
              panel.grid.minor = element_blank(),
              text = element_text(face="bold"))
      
      if(i==1) df.best<-df.rank else df.best<-rbind(df.best,df.rank)
    }
  }
  
  g[[1]]
  return(list(ranking = df.best,
              frequency = sort(table(df.best$covariates),decreasing = T),
              cicles = g))
}

######################################################################
########################  Corte de mapa  #############################
######################################################################

mapCut<-function(raster,shapefile){
  
  a<-crop(raster,shapefile)
  a<-mask(a,shapefile)
  
  return(a)
}

######################################################################
########################  Mapas tem�ticos  ###########################
######################################################################


mapGISPLS<-function(gispls, stack, cut = F,shapefile= NULL){
  
  #gispls<-fit;stack<-e
  stack<-stack[[rownames(gispls$coef)[-1]]] #Organizando na mesma ordem dos coeficientes
  gen<-gispls$genotypes
  
  if(cut ==T){
    if(is.null(shapefile) ==F) stack<-map_cut(stack,shapefile) else warning("\nCorte nao realizado, insira o Shapefile")
  }
  
  for (j in 1:length(gen)){
    
    cat("\n\nPLOTAGEM DE MAPA:",as.character(gen[j]),'\n')
    
    pls.coefs<-gispls$coef[,j] #Obtendo os coeficientes do gen�tipo
    
    
    total <- length(names(stack))
    # Barra de progresso
    pb <- txtProgressBar(min = 0, max = total, style = 3)
    
    #plotagem do mapa
    for(i in 1:length(names(stack))){
      
      if(i==1) pred <-pls.coefs[1]+stack[[i]]*pls.coefs[i+1] else pred<-pred +stack[[i]]*pls.coefs[i+1]
      
      setTxtProgressBar(pb,i)
    }
    
    names(pred)<- gen[j]
    
    
    if(j==1) PRED<-pred else PRED<-stack(PRED,pred)
    
  }
  return(PRED)
}

######################################################################
########################  Quem vence onde  ###########################
######################################################################

getX<-function(data,genotypes,region){
  #data<-data_cov; genotypes<-"MatGen_oficial"; env<-'unf'
  return(data.matrix(table(data[,genotypes],data[,region])>0))
}

rm_genotype<-function(raster,gen){
  for(i in 1:length(gen)) values(raster[[gen[i]]])<-NA
  
  return(raster)
}



whichWonWhere<- function(raster,rm_gen=NULL,by_region=F,shapefile=NULL,regions=NULL,X=NULL){
  
  #raster<-maps;rm_gen = c("CLZ003");regions="unf";by_region=T; X=X;shapefile=br
  #raster=maps
  #Removendo gen�tipos
  if(is.null(rm_gen)==F) raster<-rm_genotype(gen = rm_gen,raster = raster)
  
  
  #Fazendo quem vence onde para cara regi�o
  
  df.gen<-data.frame(Genotype = names(raster), genotype_code =1:length(names(raster)) )
  
  if(by_region==T){
    
    reg<-shapefile@data[regions][,1]
    
    
    for( i in 1:length(reg)){
      sh.reg<-shapefile[shapefile@data[,regions] %in% reg[i],]
      gen.reg<-names(X[,reg[i]][X[,reg[i]]==T])
      
      if(length(setdiff(rownames(X),gen.reg))>0) raster.reg<-rm_genotype(raster,gen =  setdiff(rownames(X),gen.reg)) else raster.reg<-raster
      
      W<-whiches.max(raster.reg) #Quem ganha onde
      
      W<-map_cut(W,sh.reg)
      
      df.r<-data.frame(table(values(W))/sum(table(values(W))))
      names(df.r)[1]<-"genotype_code"
      df.r<-merge(df.r,df.gen)
      df.r$region<- reg[i]
      
      if(i==1){
        w<-W 
        df.reg<-df.r
        
      }else{
          
        w<-merge(w,W)
        df.reg<-rbind(df.reg,df.r)
        
        }
      
      #por regiao
      
      #total
      if(i==length(reg)){
        df.rec<-data.frame(table(values(w))/sum(table(values(w))))
        names(df.rec)[1]<-"genotype_code"
        
        df.rec<-merge(df.rec,df.gen)
        
        return(list(raster = w, general_recomendation = df.rec,region_recomendation = df.reg))
      }
      
    }
    
    
  }else{
    
    w<-which.max(raster)
    df.rec<-data.frame(table(values(w))/sum(table(values(w))))
    names(df.rec)[1]<-"genotype_code"
    
    df.rec<-merge(df.rec,df.gen)
    
    return(list(raster = w, general_recomendation = df.rec))
  }
}

#Plot com ggplot2
recommendationPlot<-function(w){
  
  w_pixel <- as(w$raster, "SpatialPixelsDataFrame")
  w_df <- as.data.frame(w_pixel)
  colnames(w_df) <- c("genotype_code", "x", "y")
  
  w_df<-merge(w_df,w$general_recomendation)
  
  g<-ggplot() +  
    geom_tile(data=w_df, aes(x=x, y=y, fill=Genotype))
  
  return(g)
}
#Essa funcao e identica a funcao plsreg1 do pacote plsdepot com excessao da inversa generalizada
#SANCHEZ ,2012

plsreg1<-function (predictors, response, comps = 2, crosval = TRUE) 
{
  X = as.matrix(predictors)
  n = nrow(X)
  p = ncol(X)
  if (p < 2) 
    stop("\npredictors must contain more than one column")
  if (is.null(colnames(X))) 
    colnames(X) = paste(rep("X", p), 1:p, sep = "")
  if (is.null(rownames(X))) 
    rownames(X) = 1:n
  Y = as.matrix(response)
  if (ncol(Y) != 1) 
    stop("\nresponse must be a single variable")
  if (any(is.na(response))) 
    stop("\nresponse must not contain missing values")
  if (nrow(X) != nrow(Y)) 
    stop("\npredictors and response have different number of rows")
  if (is.null(colnames(Y))) 
    colnames(Y) = "Y"
  if (is.null(rownames(Y))) 
    rownames(Y) = 1:n
  if (any(is.na(X))) 
    na.miss = TRUE
  else na.miss = FALSE
  if (!is.null(comps)) {
    nc = comps
    if (mode(nc) != "numeric" || length(nc) != 1 || nc <= 
        1 || (nc%%1) != 0 || nc > min(n, p)) 
      nc = min(n, p)
    if (nc == n) 
      nc = n - 1
  }
  else {
    if (na.miss) {
      crosval = FALSE
      nc = 2
    }
    else {
      if (n >= 10) 
        crosval = TRUE
      else crosval = FALSE
      nc = min(n, p)
    }
  }
  if (!is.logical(crosval)) 
    crosval = FALSE
  Xx = scale(X)
  Yy = scale(Y)
  X.old = Xx
  Y.old = Yy
  Th = matrix(NA, n, nc)
  Ph = matrix(NA, p, nc)
  Wh = matrix(NA, p, nc)
  Uh = matrix(NA, n, nc)
  ch = rep(NA, nc)
  Hot = matrix(NA, n, nc)
  hlim = rep(NA, nc)
  if (crosval) {
    RSS = c(n - 1, rep(NA, nc))
    PRESS = rep(NA, nc)
    Q2 = rep(NA, nc)
    sets_size = c(rep(n%/%10, 9), n - 9 * (n%/%10))
    obs = sample(1:n, size = n)
    segments = vector("list", length = 10)
    ini = cumsum(sets_size) - sets_size + 1
    fin = cumsum(sets_size)
    for (k in 1:10) segments[[k]] = obs[ini[k]:fin[k]]
  }
  w.old = rep(1, p)
  t.new = rep(1, n)
  p.new = rep(NA, p)
  h = 1
  repeat {
    if (na.miss) {
      for (j in 1:p) {
        i.exist = which(complete.cases(X[, j]))
        w.old[j] = sum(X.old[i.exist, j] * Y.old[i.exist])
      }
      w.new = w.old/sqrt(sum(w.old^2))
      for (i in 1:n) {
        j.exist = which(complete.cases(X[i, ]))
        t.new[i] = sum(X.old[i, j.exist] * w.new[j.exist])
      }
      for (j in 1:p) {
        i.exist = intersect(which(complete.cases(X[, 
                                                   j])), which(complete.cases(t.new)))
        p.new[j] = sum(X.old[i.exist, j] * t.new[i.exist])/sum(t.new[i.exist]^2)
      }
      c.new = t(Y.old) %*% t.new/sum(t.new^2)
      u.new = Y.old/as.vector(c.new)
    }
    if (!na.miss) {
      w.old = t(X.old) %*% Y.old/sum(Y.old^2)
      w.new = w.old/sqrt(sum(w.old^2))
      t.new = X.old %*% w.new
      p.new = t(X.old) %*% t.new/sum(t.new^2)
      c.new = t(Y.old) %*% t.new/sum(t.new^2)
      u.new = Y.old/as.vector(c.new)
      if (crosval) {
        RSS[h + 1] = sum((Y.old - t.new %*% c.new)^2)
        press = rep(0, 10)
        for (i in 1:10) {
          aux = segments[[i]]
          Xy.aux = t(X.old[-aux, ]) %*% Y.old[-aux]
          wh.si = Xy.aux %*% sqrt(MASS::ginv(t(Xy.aux) %*% 
                                               Xy.aux))
          th.si = X.old[-aux, ] %*% wh.si
          ch.si = t(Y.old[-aux]) %*% th.si %*% MASS::ginv(t(th.si) %*% 
                                                            th.si)
          ch.si = as.vector(ch.si)
          Yhat.si = ch.si * X.old[aux, ] %*% wh.si
          press[i] = sum((Y.old[aux] - Yhat.si)^2)
        }
        PRESS[h] = sum(press)
        Q2[h] = 1 - PRESS[h]/RSS[h]
      }
    }
    Y.old = Y.old - (t.new %*% c.new)
    X.old = X.old - (t.new %*% t(p.new))
    Th[, h] = t.new
    Ph[, h] = p.new
    Wh[, h] = w.new
    Uh[, h] = u.new
    ch[h] = c.new
    Hot[, h] = (n/(n - 1)) * t.new^2/(sum(t.new^2)/(n - 
                                                      1))
    hlim[h] = qf(0.95, h, n - h) * (h * (n^2 - 1))/(n * 
                                                      (n - h))
    if (is.null(comps) && crosval) {
      if (Q2[h] < 0.0975 || h == nc) 
        break
    }
    else {
      if (h == nc) 
        break
    }
    h = h + 1
  }
  if (crosval) {
    q2cum = rep(NA, h)
    for (k in 1:h) q2cum[k] = prod(PRESS[1:k])/prod(RSS[1:k])
    Q2cum = 1 - q2cum
    Q2cv = cbind(PRESS[1:h], RSS[1:h], Q2[1:h], rep(0.0975, 
                                                    h), Q2cum)
    dimnames(Q2cv) = list(1:h, c("PRESS", "RSS", "Q2", "LimQ2", 
                                 "Q2cum"))
    if (is.null(comps)) 
      h = h - 1
  }
  if (!crosval) 
    Q2cv = NULL
  Th = Th[, 1:h]
  Ph = Ph[, 1:h]
  Wh = Wh[, 1:h]
  Uh = Uh[, 1:h]
  ch = ch[1:h]
  Ws = Wh %*% MASS::ginv(t(Ph) %*% Wh)
  Bs = as.vector(Ws %*% ch)
  if (!na.miss) {
    Br = Bs * (rep(apply(Y, 2, sd), p)/apply(X, 2, sd))
    cte = as.vector(colMeans(Y) - Br %*% apply(X, 2, mean))
    y.hat = as.vector(X %*% Br + cte)
    cor.xyt = cor(cbind(Xx, y = Yy), Th)
  }
  else {
    mu.x <- attributes(Xx)$"scaled:center"
    sd.x <- attributes(Xx)$"scaled:scale"
    X.hat = Th %*% t(Ph) %*% diag(sd.x, p, p) + matrix(rep(mu.x, 
                                                           each = n), n, p)
    Br = Bs * (rep(apply(Y, 2, sd), p)/sd.x)
    cte = as.vector(colMeans(response) - Br %*% mu.x)
    y.hat = as.vector(X.hat %*% Br + cte)
    cor.xyt = matrix(NA, p + 1, h)
    for (j in 1:p) {
      i.exist <- which(complete.cases(X[, j]))
      cor.xyt[j, ] = cor(Xx[i.exist, j], Th[i.exist, ])
    }
    cor.xyt[p + 1, ] = cor(Yy, Th)
  }
  resid = as.vector(Y - y.hat)
  R2 = as.vector(cor(Th, Yy))^2
  R2Xy = t(apply(cor.xyt^2, 1, cumsum))
  T2hot = rbind(hlim[1:h], t(apply(Hot[, 1:h], 1, cumsum)))
  dimnames(Wh) = list(colnames(X), paste(rep("w", h), 1:h, 
                                         sep = ""))
  dimnames(Ws) = list(colnames(X), paste(rep("w*", h), 1:h, 
                                         sep = ""))
  dimnames(Th) = list(rownames(X), paste(rep("t", h), 1:h, 
                                         sep = ""))
  dimnames(Ph) = list(colnames(X), paste(rep("p", h), 1:h, 
                                         sep = ""))
  dimnames(Uh) = list(rownames(Y), paste(rep("u", h), 1:h, 
                                         sep = ""))
  names(ch) = paste(rep("c", h), 1:h, sep = "")
  dimnames(T2hot) = list(c("T2", rownames(X)), paste(rep("H", 
                                                         h), 1:h, sep = ""))
  names(Bs) = colnames(X)
  names(Br) = colnames(X)
  names(resid) = rownames(Y)
  names(y.hat) = rownames(Y)
  names(R2) = paste(rep("t", h), 1:h, sep = "")
  colnames(R2Xy) = paste(rep("t", h), 1:h, sep = "")
  dimnames(cor.xyt) = list(c(colnames(X), colnames(Y)), colnames(Th))
  res = list(x.scores = Th, x.loads = Ph, y.scores = Uh, y.loads = ch, 
             cor.xyt = cor.xyt, raw.wgs = Wh, mod.wgs = Ws, std.coefs = Bs, 
             reg.coefs = c(Intercept = cte, Br), R2 = R2, R2Xy = R2Xy, 
             y.pred = y.hat, resid = resid, T2 = T2hot, Q2 = Q2cv, 
             y = response)
  class(res) = "plsreg1"
  return(res)
}

